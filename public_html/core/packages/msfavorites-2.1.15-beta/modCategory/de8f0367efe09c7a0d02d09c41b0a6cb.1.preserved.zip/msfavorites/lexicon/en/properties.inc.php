<?php

$_lang['msfavorites_prop_frontCss'] = 'File with css styles to connect to the frontend.';
$_lang['msfavorites_prop_frontJs'] = 'The file with javascript to connect to the frontend.';
$_lang['msfavorites_prop_actionUrl'] = 'Connector to handle ajax requests.';
$_lang['msfavorites_prop_list'] = 'Arbitrary name a favorite list. ';
$_lang['msfavorites_prop_sortby'] = 'The field to sort by. Ex: "&sortby=`{"timestamp":"ASC"}`"';
$_lang['msfavorites_prop_toPlaceholder'] = 'If not empty, the snippet will save all data placeholder with the same name, instead of displaying the screen not.';
