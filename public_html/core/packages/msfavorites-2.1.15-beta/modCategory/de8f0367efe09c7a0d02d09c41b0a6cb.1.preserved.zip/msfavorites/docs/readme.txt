--------------------
msFavorites
--------------------
Author: Vgrish <vgrish@gmail.com>
--------------------
