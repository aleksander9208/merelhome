<?php
require_once (dirname(dirname(__FILE__)) . '/ticketstar.class.php');
class TicketStar_mysql extends TicketStar {}