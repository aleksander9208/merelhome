<?php
require_once (dirname(dirname(__FILE__)) . '/ticketauthor.class.php');
class TicketAuthor_mysql extends TicketAuthor {}