<?php
require_once (dirname(dirname(__FILE__)) . '/ticketssection.class.php');
class TicketsSection_mysql extends TicketsSection {}