<?php

$_lang['area_msfavorites_main'] = 'Основные';

$_lang['setting_msfavorites_front_js'] = 'Файл с javascript';
$_lang['setting_msfavorites_front_js_desc'] = 'Файл с javascript для подключения на фронтенде. ';

$_lang['setting_msfavorites_front_css'] = 'Файл с css';
$_lang['setting_msfavorites_front_css_desc'] = 'Файл с css для подключения на фронтенде. ';

$_lang['setting_msfavorites_clear_temporary'] = 'Очищать временные';
$_lang['setting_msfavorites_clear_temporary_desc'] = 'Разрешить очищать список временного избранного при очистке кеша. ';

$_lang['setting_msfavorites_time_limit'] = 'Лимит времени';
$_lang['setting_msfavorites_time_limit_desc'] = 'Лимит времени. Задается в днях.';
