<?php
require_once (dirname(__DIR__) . '/ticketfile.class.php');
class TicketFile_mysql extends TicketFile {}