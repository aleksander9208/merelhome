<?php
include_once MODX_CORE_PATH . 'model/modx/processors/system/settings/updatefromgrid.class.php';

class settingsWidgetUpdateProcessor extends modSystemSettingsUpdateFromGridProcessor {

}
return 'settingsWidgetUpdateProcessor';
