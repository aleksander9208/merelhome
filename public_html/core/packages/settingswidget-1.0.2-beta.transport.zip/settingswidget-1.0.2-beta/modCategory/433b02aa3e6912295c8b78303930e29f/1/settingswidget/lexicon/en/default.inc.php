<?php
include_once 'setting.inc.php';

$_lang['settingswidget'] = 'settingsWidget';
$_lang['message'] = 'Fast settings. Edit by double-click';
$_lang['name'] = 'Name';
$_lang['value'] = 'Value';
$_lang['emptykeys'] = 'Specify the configuration keys to display them in this widget';
