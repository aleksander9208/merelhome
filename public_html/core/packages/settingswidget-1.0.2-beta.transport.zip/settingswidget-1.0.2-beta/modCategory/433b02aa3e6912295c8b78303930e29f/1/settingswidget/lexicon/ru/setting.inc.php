<?php

$_lang['area_settingswidget_main'] = 'Основные';

$_lang['setting_settingswidget_keys'] = 'Ключи настроек в виджете';
$_lang['setting_settingswidget_keys_desc'] = 'Ключи настроек в виджете через запятую. Например: access_category_enabled,emailsubject,blocked_minutes.';

