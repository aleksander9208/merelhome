<?php
include_once 'setting.inc.php';

$_lang['settingswidget'] = 'settingsWidget';
$_lang['message'] = 'Быстрые настройки сайта. Редактируются двойным кликом';
$_lang['name'] = 'Название';
$_lang['value'] = 'Значение';
$_lang['emptykeys'] = 'Укажите ключи настроек для отображения их в этом виджете';
