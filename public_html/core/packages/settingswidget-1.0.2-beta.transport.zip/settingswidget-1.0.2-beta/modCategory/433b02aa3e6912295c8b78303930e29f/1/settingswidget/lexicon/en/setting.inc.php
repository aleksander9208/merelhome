<?php

$_lang['area_settingswidget_main'] = 'Main';

$_lang['setting_settingswidget_keys'] = 'Settings keys';
$_lang['setting_settingswidget_keys_desc'] = 'Settings keys that will be shown in the widget. Example: access_category_enabled,emailsubject,blocked_minutes.';
