--------------------
simpleUpdater
--------------------
Author: Ilya Utkin <ilyautkin@mail.ru>
--------------------

MODX addon updating MODX version on site.

Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/ilyautkin/simpleUpdater