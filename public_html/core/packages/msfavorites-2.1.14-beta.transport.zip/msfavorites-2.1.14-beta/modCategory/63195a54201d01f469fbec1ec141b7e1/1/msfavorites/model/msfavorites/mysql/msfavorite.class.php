<?php
require_once (dirname(__DIR__) . '/msfavorite.class.php');
class msFavorite_mysql extends msFavorite {}