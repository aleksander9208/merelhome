<?php

$_lang['area_msfavorites_main'] = 'Main';

$_lang['setting_msfavorites_front_js'] = 'File with javascript';
$_lang['setting_msfavorites_front_js_desc'] = 'The file with javascript to connect to the frontend. ';

$_lang['setting_msfavorites_front_css'] = 'File with css styles';
$_lang['setting_msfavorites_front_css_desc'] = 'File with css styles to connect to the frontend. ';

$_lang['setting_msfavorites_clear_temporary'] = 'Clear temporary';
//$_lang['setting_msfavorites_clear_temporary_desc'] = 'Разрешить очищать список временного избранного при очистке кеша. ';

$_lang['setting_msfavorites_time_limit'] = 'Time limit';
//$_lang['setting_msfavorites_time_limit_desc'] = 'Лимит времени. Задается в днях.';
