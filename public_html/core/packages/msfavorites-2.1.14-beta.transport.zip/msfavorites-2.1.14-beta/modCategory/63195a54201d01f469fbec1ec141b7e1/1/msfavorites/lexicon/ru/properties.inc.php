<?php

$_lang['msfavorites_prop_frontCss'] = 'Файл с css стилями для подключения на фронтенде.';
$_lang['msfavorites_prop_frontJs'] = 'Файл с javascript для подключения на фронтенде.';
$_lang['msfavorites_prop_actionUrl'] = 'Коннектор для обработки ajax запросов.';
$_lang['msfavorites_prop_list'] = 'Произвольное имя списка избранного. ';
$_lang['msfavorites_prop_sortby'] = 'Сортировка выборки. Например: "&sortby=`{"timestamp":"ASC"}`"';
$_lang['msfavorites_prop_toPlaceholder'] = 'Если не пусто, сниппет сохранит все данные в плейсхолдер с этим именем, вместо вывода не экран.';
