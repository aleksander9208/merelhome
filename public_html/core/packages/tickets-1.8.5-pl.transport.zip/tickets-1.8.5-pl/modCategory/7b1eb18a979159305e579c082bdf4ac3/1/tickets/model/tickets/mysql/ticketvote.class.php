<?php
require_once (dirname(__DIR__) . '/ticketvote.class.php');
class TicketVote_mysql extends TicketVote {}